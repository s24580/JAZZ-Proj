mapper dla:
games,players

potem map wszystko co w games.
updater
