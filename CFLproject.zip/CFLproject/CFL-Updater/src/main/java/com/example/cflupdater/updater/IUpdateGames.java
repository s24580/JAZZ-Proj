package com.example.cflupdater.updater;

public interface IUpdateGames {

    void updateGames(int season);

//    void updateGameAll();
}
