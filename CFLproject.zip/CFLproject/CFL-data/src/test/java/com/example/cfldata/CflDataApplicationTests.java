package com.example.cfldata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CflDataApplicationTests {

    @Test
    void contextLoads() {
    }

}
