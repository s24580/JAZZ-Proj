package com.example.cfldata.repositories;

import com.example.cfldata.model.CoinToss;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoinTossRepository extends JpaRepository<CoinToss,Long> {

}
