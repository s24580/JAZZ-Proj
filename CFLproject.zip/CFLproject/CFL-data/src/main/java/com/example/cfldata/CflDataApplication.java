package com.example.cfldata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CflDataApplication {

    public static void main(String[] args) {
        SpringApplication.run(CflDataApplication.class, args);
    }

}
