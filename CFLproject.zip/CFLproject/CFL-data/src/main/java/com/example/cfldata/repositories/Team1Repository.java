package com.example.cfldata.repositories;

import com.example.cfldata.model.CoinToss;
import com.example.cfldata.model.Team1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Team1Repository extends JpaRepository<Team1,Long> {
}
