//package com.example.cfldata.repositories;
//
//import com.example.cfldata.model.CoinToss;
//import com.example.cfldata.model.LinescoreTeam1;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface LinescoreTeam1Repository extends JpaRepository<LinescoreTeam1,Long> {
//}
