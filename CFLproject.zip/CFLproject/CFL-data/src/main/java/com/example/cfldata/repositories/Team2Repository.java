package com.example.cfldata.repositories;

import com.example.cfldata.model.CoinToss;
import com.example.cfldata.model.Team2;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Team2Repository extends JpaRepository<Team2,Long> {
}
