//package com.example.cflclient.cflclient;
//
//import org.springframework.beans.factory.annotation.Value;
//
//public class CFLClientConfiguration {
//
//    public ICFLClientSettings getSetting(
//            @Value("${CFLkey}") String apiKey,
//            @Value("api.cfl.ca/v1") String host){
//        return new CFLClientSettings();
//    }
//}
